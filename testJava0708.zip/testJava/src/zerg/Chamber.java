package zerg;

public class Chamber {
	public void upgradeAttack(){
		Hydra.attack++;
		Ultra.attack++;
	}
	
	public void upgradeArmor(){
		Hydra.armor++;
		Ultra.armor++;
	}
}
