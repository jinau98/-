package zerg;

public class ZergApp {
	public static void attack(Zerg u1, Zerg u2) {
		int damage = u1.getAttack() - u2.getArmor();
		u2.setSt(u2.getSt() - damage);
	}

	public static void printUnit(Zerg u) {
		System.out.println(u.getName() + "�� ü���� " + u.getSt());
	}

	public static void main(String[] args) {
		Hatchery hat = new Hatchery();

		Hydra h1 = hat.makeHydra();
		Hydra h2 = hat.makeHydra();

		Ultra ul1 = hat.makeUltra();
		Ultra ul2 = hat.makeUltra();

		ZergApp.attack(h1, ul2);
		ZergApp.printUnit(ul2);

		ZergApp.attack(ul1, ul2);
		ZergApp.printUnit(ul2);

		ZergApp.printUnit(ul2);

		Chamber CH = new Chamber();
		CH.upgradeAttack();
		CH.upgradeArmor();

		Hydra h3 = new Hydra();
		System.out.println("������� ���ݷ� : " + h1.getAttack());
		System.out.println("������� ���� : " + h1.getArmor());
	}
}
