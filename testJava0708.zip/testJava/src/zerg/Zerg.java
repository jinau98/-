package zerg;

import starcraft.Starcraft;

public abstract class Zerg implements Starcraft{
	
}
