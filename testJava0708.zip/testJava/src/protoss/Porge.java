package protoss;

public class Porge {
	public void upgradeAttack(){
		Zealot.attack++;
		Dragoon.attack++;
		DarkTempler.attack++;
	}
	public void upgradeArmor(){
		Zealot.armor++;
		Dragoon.armor++;
		DarkTempler.armor++;
	}
}
