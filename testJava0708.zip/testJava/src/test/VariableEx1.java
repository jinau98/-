package test;

public class VariableEx1 {
	public static void main(String[] args) {
		boolean b = true;					//1bit
		byte a=1;								//8bit
		char ch = 'A';							//16bit
		int n = 100;							//32bit
		double d = 10.5;						//64bit
		
		System.out.println(b);
		System.out.println(a);
		System.out.println(ch);
		System.out.println(n);
		System.out.println(d);
	}
}
