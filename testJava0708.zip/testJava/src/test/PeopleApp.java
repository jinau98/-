package test;

class People{
	String getName(){
		return null;
	}
}

class �߼� extends People{
	String name="�߼�";
	
	@Override
	String getName() {
		return name;
	}
}

class �Ѱ� extends People{
	String name="�Ѱ�";
	@Override
	String getName() {
		return name;
	}
	
}

public class PeopleApp {
	static void start(People p){
		System.out.println(p.getName());
	}
	public static void main(String[] args) {
		start(new �Ѱ�());
		start(new �߼�());

	}

}
