
public class Menu {
	
}
