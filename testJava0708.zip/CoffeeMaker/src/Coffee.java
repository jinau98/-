
public class Coffee {

}
