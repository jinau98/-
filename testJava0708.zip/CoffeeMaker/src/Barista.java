
public class Barista {

}
