import org.json.simple.JSONObject;

class Data{
	int movie_count = 12499;
	int limit =3;
	int page_number=1;
}

class Response{
	String status="ok";
	String status_message="query was success";
	Data data = new Data();
}
public class JsonTest2 {
	public static void main(String[] args) {
		JSONObject Data =new JSONObject();
		
		Data.put("movie_count", 12499);
		Data.put("limit", 3);
		Data.put("page_number", 1);
		
		JSONObject Response = new JSONObject();
		
		Response.put("status", "ok");
		Response.put("status_message", "query was success");
		
		Data.put("Data", Response);
		
		System.out.println(Data);
	}
}
