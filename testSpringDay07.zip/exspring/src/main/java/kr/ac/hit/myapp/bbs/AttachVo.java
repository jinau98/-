package kr.ac.hit.myapp.bbs;

public class AttachVo {
	private int attNo; 
	private String attOrgName;
	private String attNewName;
	private int attBbsNo;
	
	public int getAttNo() {
		return attNo;
	}
	public void setAttNo(int attNo) {
		this.attNo = attNo;
	}
	public String getAttOrgName() {
		return attOrgName;
	}
	public void setAttOrgName(String attOrgName) {
		this.attOrgName = attOrgName;
	}
	public String getAttNewName() {
		return attNewName;
	}
	public void setAttNewName(String attNewName) {
		this.attNewName = attNewName;
	}
	public int getAttBbsNo() {
		return attBbsNo;
	}
	public void setAttBbsNo(int attBbsNo) {
		this.attBbsNo = attBbsNo;
	}
}
