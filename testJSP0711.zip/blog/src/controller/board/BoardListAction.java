package controller.board;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import controller.Action;

public class BoardListAction implements Action{

    private static final String TAG = "BoardListAction : ";

	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		System.out.println(TAG+"����");
		String url = "board/list.jsp";
		response.sendRedirect(url);
	}
	
}
