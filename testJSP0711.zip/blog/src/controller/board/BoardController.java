package controller.board;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import controller.Action;

@WebServlet("/board")
public class BoardController extends HttpServlet {
	private static final long serialVersionUID = 1L;
    private static final String TAG = "BoardController : ";
 

    public BoardController() {
        super();
    }


	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {		//select-get��û
		System.out.println(TAG+"����(GET)");
		doJoin(request, response);

	}


	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {		//select ���� ��ȭ �ִ� ��� -post��û
		System.out.println(TAG+"����(POST)");
		doJoin(request, response);
	}
	
	protected void doJoin(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {		
		request.setCharacterEncoding("UTF-8");
		System.out.println(TAG+"�ѱ�ó���Ϸ�(UTF-8)");
		String cmd = request.getParameter("cmd");
		System.out.println(TAG+cmd+"��û ��");
		Action action=BoardFactory.router(cmd);
		action.execute(request, response);
	}

}
