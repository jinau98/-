package kr.ac.hit.ex;

public interface Greet {
	public void say();
}
