package controller.board;

import controller.Action;
import controller.error.ErrorAction;

public class BoardFactory {
	public static Action router(String cmd){
		if(cmd==null || cmd.equals("") || cmd.equals("list")){
			return new BoardListAction();
		}else if(cmd.equals("view")){
			return new BoardViewAction();
		}else if(cmd.equals("update")){
			return new BoardUpdateAction();
		}else if(cmd.equals("write")){
			//글쓰기 페이지로 이동
			return new BoardWriteAction();
		}else if(cmd.equals("writeProc")){
			//글쓰기로 DB에 반영
			return new BoardWriteProcAction();
		}else if(cmd.equals("delete")){
			return new BoardDeleteAction();
		}
		
		return new ErrorAction();
	}
}
