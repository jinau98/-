package controller.board;

import controller.Action;
import controller.ErrorAction;

public class BoardFactory {
	public static Action router(String cmd){
		if(cmd==null||cmd.equals("")||cmd.equals("list")){
			return new BoardListAction();
		}else if(cmd.equals("view")){
			return new BoardViewAction();
		}else if(cmd.equals("update")){
			return new BoardUpadateAction();
		}else if(cmd.equals("write")){
			return new BoardWriteAction();
		}
		return new ErrorAction();
	}
}
