package controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

// URI(identifier) - http://localhost:8282/factory/board 
@WebServlet("/board")
public class BoardController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	private static final String TAG = "BoardController : ";		//�±׵��� ��½��� ������ ã�� �� �ְ� ��
	
	public void execute(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		System.out.println(TAG+"����");
		String url = "board/list.jsp";
		response.sendRedirect(url);
	}
    public BoardController() {
        super();
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		System.out.println(TAG+"����� ��û�� ���۵Ǿ����ϴ�.");
		request.setCharacterEncoding("UTF-8");
		System.out.println(TAG+"�ѱ�ó�� �Ϸ��");
		String cmd = request.getParameter("cmd");
		System.out.println(TAG+cmd+"��û ��");
		ActionFactory af = ActionFactory.getInstance();
		Action action = af.router(cmd);
		action.execute(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

}
