package repository;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import model.Board;
import model.Reply;

//save(), update(), findAll(), findById(), findByIdAndPw(), delete()
public class BoardRepository {
	private PreparedStatement pstmt;
	private ResultSet rs;

	public int delete(int num) {
		String sql = "DELETE FROM board WHERE num = ?";
		// stream 연결 (java <-> db) 선
		Connection conn = DBConnection.getConnection();

		try {
			// query를 적을 수 있게 준비 - 아직 query가 완성되지는 않았음.
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, num);
			int result = pstmt.executeUpdate(); // commit, rollback
			// result == 1이면 정상, 1이 아니면 비정상
			return result;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return -1;
	} // end of delete
	
	public int save(Board b) {
		String sql = "INSERT INTO board(username, title, content) VALUES(?,?,?)";
		// stream 연결 (java <-> db) 선
		Connection conn = DBConnection.getConnection();

		try {
			// query를 적을 수 있게 준비 - 아직 query가 완성되지는 않았음.
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, b.getUsername());
			pstmt.setString(2, b.getTitle());
			pstmt.setString(3, b.getContent());
			int result = pstmt.executeUpdate(); // commit, rollback
			// result == 1이면 정상, 1이 아니면 비정상
			return result;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return -1;
	} // end of save
	
	public List<Reply> findByBoardId(int boardId) {
		String sql = "SELECT num, username, content, boardId FROM reply WHERE boardId = ?";
		Connection conn = DBConnection.getConnection();
		List<Reply> replys = new ArrayList<>();
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, boardId);
			rs = pstmt.executeQuery();
			while (rs.next()) {
				Reply r = new Reply();
				r.setNum(rs.getInt("num"));
				r.setUsername(rs.getString("username"));
				r.setContent(rs.getString("content"));
				r.setBoardId(rs.getInt("boardId"));
				replys.add(r);
			}
			return replys;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	} 
	
	public List<Board> findAll() {
		String sql = "SELECT num, title, username FROM board";
		Connection conn = DBConnection.getConnection();
		List<Board> boards = new ArrayList<>();
		try {
			pstmt = conn.prepareStatement(sql);
			rs = pstmt.executeQuery();
			while (rs.next()) {
				Board b = new Board();
				b.setNum(rs.getInt("num"));
				b.setTitle(rs.getString("title"));
				b.setUsername(rs.getString("username"));
				boards.add(b);
			}
			return boards;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	} // end of findAll

	public Board findByNum(int num) {
		String sql = "SELECT num, title, username, content FROM board WHERE num=?";
		Connection conn = DBConnection.getConnection();
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, num);
			rs = pstmt.executeQuery();
			if (rs.next()) {
				Board b = new Board();
				b.setNum(rs.getInt("num"));
				b.setTitle(rs.getString("title"));
				b.setUsername(rs.getString("username"));
				b.setContent(rs.getString("content"));
				return b;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}
}
