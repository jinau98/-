package controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import action.Action;
import repository.BoardRepository;

public class BoardDeleteAction implements Action{

	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String url = "/board";		//index.jsp -> /board/router?cmd=list
		
		int num = Integer.parseInt(request.getParameter("num"));
		
		//모델 연결
		BoardRepository br = new BoardRepository();
		int b = br.delete(num);
		
		if(b!=1){
			RequestDispatcher dis = request.getRequestDispatcher(url);
			dis.forward(request, response);
		}else{
			response.sendRedirect("/board");
		}
	}

}
