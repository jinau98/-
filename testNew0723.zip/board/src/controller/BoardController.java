package controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import action.Action;
import action.BoardFactory;

//WebServlet 어노테이션으로 접근하는 방법
//http://ip주소:포트번호/컨텍스트패스(프로젝트)/WebServlet이름
//http://localhost:8080/board/router
@WebServlet("/router")
public class BoardController extends HttpServlet {
	private static final long serialVersionUID = 1L;

    public BoardController() {
        super();
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//System.out.println("GET요청이 들어옴");
		doProcess(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//System.out.println("POST요청이 들어옴");
		doProcess(request, response);
	}
	
	protected void doProcess(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");
		response.setContentType("text/html; charset=UTF-8"); 
		
		//cmd값으로 분기하기
		String cmd = request.getParameter("cmd");
		System.out.println(cmd);
		
		//팩토리에 위임
		Action action = BoardFactory.getAction(cmd);
		if(action != null) action.execute(request, response);
	}

}
