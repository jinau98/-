

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

//라우팅 임무를 하는 서블릿
@WebServlet("/board")									//java 파일로 접근 - 보안
public class Controller extends HttpServlet {
	private static final long serialVersionUID = 1L;

    public Controller() {
        super();
    }


	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//스트림에 버퍼를 연결
//		PrintWriter out = response.getWriter();
//		out.println("<html>");
//		out.println("<body>");
//		out.println("<h1>URI TEST<h1>");
//		out.println("</body>");
//		out.println("</html>");
//		int number = 10;
//		response.sendRedirect("board.jsp");							//라우팅 역할 java 파일 안에 html 소스를 넣지 않아도 됨
		
//		String uri = request.getRequestURI();
//		String queryString =request.getQueryString();
//		System.out.println(uri);			//uri = /last/board
//		System.out.println(queryString);
//		// (1) java 결과를 .jsp로 어떻게 넘길까?
//		// (2) 라우팅하는 것이 한 군데로만 넘어간다.
		
//		//쿼리스트링 파싱
//		String arr[] = queryString.split("=");
//		String cmd=arr[1];
//		System.out.println(cmd);				//index
		
		String cmd = request.getParameter("cmd");
		
		if(cmd.equals("insert")){
			String name = "JINU";
			RequestDispatcher dis = request.getRequestDispatcher("board/insert.jsp");				//request와 rsesponse 두 개의 객체를 담고 이동
			request.setAttribute("name", name);
			dis.forward(request, response);
			response.sendRedirect("board/insert.jsp");										//sendRedirect() 파일을 직렬화, 바이트로 바꿔 스트림을 통해 파일을 보내주기만 함
		}else if(cmd.equals("delete")){
			response.sendRedirect("board/delete.jsp");
		}else if(cmd.equals("update")){
			response.sendRedirect("board/update.jsp");
		}else if(cmd.equals("select")){
			RequestDispatcher dis = request.getRequestDispatcher("board/select.jsp");				//request와 rsesponse 두 개의 객체를 담고 이동
			int number = 10;
			request.setAttribute("number", number);
			dis.forward(request, response);
//			response.sendRedirect("board/select.jsp");
		}else{
			response.sendRedirect("index.jsp");
		}
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

}
