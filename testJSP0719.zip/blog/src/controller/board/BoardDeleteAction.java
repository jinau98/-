package controller.board;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import controller.Action;
import model.Board;
import repository.BoardRepository;
import util.Script;

public class BoardDeleteAction implements Action{

	private static final String TAG = "BoardDeleteAction : ";
	
	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		System.out.println(TAG+"진입");
		String url = "/blog";
		
		
		//request로 받기
		int id=Integer.parseInt(request.getParameter("id"));
		
		BoardRepository br = new BoardRepository();
		int result = br.delete(id);
		
		if(result==1){
			
		}else{
			Script.back(response);
		}
		response.sendRedirect(url);
		
	}
}
