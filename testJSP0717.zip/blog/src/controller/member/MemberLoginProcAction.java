package controller.member;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import controller.Action;
import repository.MemberRepository;
import util.Script;

public class MemberLoginProcAction implements Action{

	private static final String TAG = "MemberLoginProcAction : ";
	
	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		System.out.println(TAG+"진입");
		String url = "/blog";
		String username = request.getParameter("username");
		String password=request.getParameter("password");
		//DB연결 - username, password 동일한 것 있는지 확인
		MemberRepository mr = new MemberRepository();
		int result = mr.findByUsernameAndPassword(username, password);
		
		//인증 --> 세션에 등록
		if(result==1){
			HttpSession session = request.getSession();
			session.setAttribute("username", username);
				response.sendRedirect(url);	
		}else{
			Script.back(response,"로그인에 실패했습니다");
		}

	}
}
