
public class Test2 {
	public static void main(String[] args) {
		//Max length()는 영어 기준 192자
		//Max length()는 한글 기준 64자
			
		String content = "안녕 Hello 안녕 Hello 안녕 Hello 안녕 Hello 안녕 Hello 안녕 Hello 안녕 Hello 안녕 Hello 안녕 Hello 안녕 Hello 안녕 Hello 안녕 Hello 안녕 Hello 안녕 ";

		int index =64;
		while(true){
			if(content.getBytes().length > 192){
				content = content.substring(0, index);
				index--;
			}else{
				content += "...";
				break;
			}
		}

		System.out.println(content);
	}
}
