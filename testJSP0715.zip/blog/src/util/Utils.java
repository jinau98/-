package util;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;

public class Utils {	
	public static String previewSlice(String content) {
		if(content.length()>80){
		content = content.substring(0, 80);
		content +="...";
		}
		return content;
	}
	
	public static String previewParsing(String content){
			Document doc = Jsoup.parse(content);
			try {
				
			Element p = doc.selectFirst("<p>");
			String result= p.text();
			result = previewSlice(result);
			result = "<p>"+result+"</p>";
			System.out.println(result);
			return null;
			} catch (Exception e) {
				return content;
			}
	}
	

	

}
