package controller.member;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import controller.Action;

@WebServlet("/member")
public class MemberController extends HttpServlet {
	private static final long serialVersionUID = 1L;
    private static final String TAG = "MemberController : ";
 

    public MemberController() {
        super();
    }


	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {		//select-get��û
		System.out.println(TAG+"����(GET)");
		doJoin(request, response);

	}


	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {		//select ���� ��ȭ �ִ� ��� -post��û
		System.out.println(TAG+"����(POST)");
		doJoin(request, response);
	}
	
	protected void doJoin(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {		
		request.setCharacterEncoding("UTF-8");
		System.out.println(TAG+"�ѱ�ó���Ϸ�(UTF-8)");
		String cmd = request.getParameter("cmd");
		System.out.println(TAG+cmd+"��û ��");
		Action action=MemberFactory.router(cmd);
		action.execute(request, response);
	}

}
