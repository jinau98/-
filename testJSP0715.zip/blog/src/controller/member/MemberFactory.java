package controller.member;

import controller.Action;
import controller.ErrorAction;
import controller.board.BoardListAction;

public class MemberFactory {
	public static Action router(String cmd){
		if(cmd==null||cmd.equals("")){
			return new BoardListAction();
		}else if(cmd.equals("join")){
			return new MemberJoinAction();
		}else if(cmd.equals("update")){
			return new MemberUpadateAction();
		}else if(cmd.equals("login")){
			return new MemberLoginAction();
		}else if(cmd.equals("joinProc")){
			return new MemberJoinProcAction();
		}
		return new ErrorAction();
	}
}
