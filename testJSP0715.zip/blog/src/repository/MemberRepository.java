package repository;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import model.Member;
import util.DBManager;

//DAO -> DataAccessObject
public class MemberRepository {
	private PreparedStatement pstmt;
	private ResultSet rs;
	
	public int save(Member m) { 

		final String SQL = "INSERT INTO member(username, password, email, createDate) VALUES(?,?,?,now())";
		Connection conn = DBConnection.getConnection();
		try { 
			pstmt = conn.prepareStatement(SQL);
			pstmt.setString(1, m.getUsername());
			pstmt.setString(2, m.getPassword());
			pstmt.setString(3, m.getEmail());
			
			int result = pstmt.executeUpdate(); 
			return result;
		} catch (Exception e) {
			e.printStackTrace();
		} finally { // try�� �����ų� catch�� ������ ���� (������ ����!!!)
			DBManager.dbClose(conn, pstmt);

		}
		return -1;		//����
	}
}
