
public class BurgerKing {
	public static void main(String[] args) {
		ShrimpWhopper s1 = new ShrimpWhopper();
		Coke c1 = new Coke();
		FrenchFries f1 = new FrenchFries();

		System.out.println(s1.getName());
		System.out.println(c1.getName());
		System.out.println(f1.getName());
		ShrimpWpSet sws = new ShrimpWpSet(new ShrimpWhopper(), new Coke(), new FrenchFries());
		
		System.out.println(sws.getPrice());
		System.out.println(sws.getName());
	}
}
