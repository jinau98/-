
public class ShrimpWpSet {
	private ShrimpWhopper shrimpWhopper;
	private Coke coke;
	private FrenchFries frenchFries;
	
	//������ �ο� - ������
	public ShrimpWpSet(ShrimpWhopper shrimpWhopper, Coke coke, FrenchFries frenchFries) {
		super();
		this.shrimpWhopper = shrimpWhopper;
		this.coke = coke;
		this.frenchFries = frenchFries;
	}
	
	public int getPrice(){
		int price = shrimpWhopper.getPrice() + coke.getPrice() + frenchFries.getPrice()-1000;
		return price;
	}

	public String getName(){
		StringBuilder sb = new StringBuilder();
		sb.append(shrimpWhopper.getName()+" ");
		sb.append(coke.getName()+ " ");
		sb.append(frenchFries.getName());
		
		return sb+""; 				//return sb.toString(); 		�� �� String���� �ٲ��ִ� ���
	}
	
}
