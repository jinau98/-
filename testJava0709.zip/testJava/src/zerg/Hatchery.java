package zerg;

public class Hatchery {
	public Hydra makeHydra(){
		return new Hydra();
	}
	
	public Ultra makeUltra(){
		return new Ultra();
	}
}
