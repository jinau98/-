package zerg;

public class Hydra extends Zerg {
	public Hydra(){
		this(100);
	}
	
	public Hydra(int st){
		this.st=st;
		
		System.out.println("���Ƥ���������������");
	}
	final String name="�����";
	int st;
	static int attack=10;
	static int armor=1;
	
	@Override
	public String getName() {
		return name;
	}

	@Override
	public int getSt() {
		return st;
	}

	@Override
	public int getAttack() {
		return attack;
	}

	@Override
	public int getArmor() {
		return armor;
	}

	@Override
	public void setSt(int st) {
		this.st=st;
	}
	
}
