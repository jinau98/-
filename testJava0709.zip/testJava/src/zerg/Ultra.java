package zerg;

public class Ultra extends Zerg{
	public Ultra(){
		this(100);
	}
	
	public Ultra(int st){
		this.st=st;
		
		System.out.println("��ň��������������");
	}
	final String name="��Ʈ��";
	int st;
	static int attack=30;
	static int armor=1;
	
	@Override
	public String getName() {
		return name;
	}

	@Override
	public int getSt() {
		return st;
	}

	@Override
	public int getAttack() {
		return attack;
	}

	@Override
	public int getArmor() {
		return armor;
	}

	@Override
	public void setSt(int st) {
		this.st=st;
	}
}
