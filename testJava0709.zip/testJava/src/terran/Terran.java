package terran;

import starcraft.Starcraft;

public abstract class Terran implements Starcraft{
	
}