import org.json.simple.JSONArray;
import org.json.simple.JSONObject;

class info{
	String name = "������";
	String phone = "0105216742";
}
class Account{
	String account = "172-2045-22";;
	String password = "1234";
	
	info info =new info();
	String time[]={"2019-0701","2019-07-03", "2019-07-05"};
}
public class JsonTest {
	public static void main(String[] args) {
		String jsonString = "{\"name\":\"������\", \"phone\":\"01052167642}\", time:[\"2019-0701\", \"2019-07-03\"]}";				//json Ư¡ {�� �����ؼ� }�� ����, ��� ���ڿ� "" �־���� ��
		System.out.println(jsonString);
		
		JSONObject js = new JSONObject();
		
		js.put("account", "172-2034-22");
		js.put("password", 1234);
		
		
		JSONObject info = new JSONObject();
		info.put("name", "������");
		info.put("phone",	"01052167642");
		
		js.put("info", info);
		
		JSONArray arr= new JSONArray();
		arr.add("2019-07-01");
		arr.add("2019-07-03");
		
		js.put("date", arr);
		System.out.println(js);


	}
}
