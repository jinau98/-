import java.util.ArrayList;
import java.util.List;

public class MainApp {
	public static void main(String[] args) {
		Cashier cashier = new Cashier();
		Customer customer = new Customer();
		Barista barista = new Barista();
		
		Menu menu = barista.makeMenu();
		
		//Ŀ�Ǹ� �ֹ��϶�!
		customer.order(CoffeeList.MACCHIATO, menu, barista, cashier);
		
		System.out.println();
		System.out.println("=====�ֹ����======");
		for(String item : cashier.orderList){
			System.out.println(item);
		}
	}
}
