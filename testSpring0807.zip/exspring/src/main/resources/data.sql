-- 실습용으로 배포된 mysql 실행 (포트 3306)
-- 실행방법 : C:\eGovFrame-3.7.0\bin\mysql-5.6.21\startup.bat 더블클릭
-- 종료방법 : C:\eGovFrame-3.7.0\bin\mysql-5.6.21\stop.bat 더블클릭
-- 접속 정보 (Database/username/password) : com/com/com01 , hyb/hyb/hyb01, mobile/mobile/mobile01 
-- Data Source Explorer에 이미 com 커넥션 정보가 등록되어 있음

-- MEMBER 테이블 생성 
-- MEM_ID, MEM_PASS, MEM_NAME, MEM_POINT 컬럼을 정의
CREATE TABLE member
( mem_id VARCHAR(50) PRIMARY KEY,
  mem_pass VARCHAR(50),
  mem_name VARCHAR(50),
  mem_point NUMERIC(10,0)
-- , mem_reg_date DATETIME DEFAULT CURRENT_TIMESTAMP
-- , PRIMARY KEY ('mem_id')
);
alter table member add mem_img varchar(100);

select * from member;
SELECT  mem_id as memId, mem_pass as memPass, mem_name as memName, mem_point as memPoint FROM member;

-- BBS 테이블 생성  
-- MySQL 5.6.5, MariaDB 10.0 버전부터 DEFAULT CURRENT_TIMESTAMP, ON UPDATE CURRENT_TIMESTAMP 설정 가능
CREATE TABLE bbs
( bbs_no INT PRIMARY KEY AUTO_INCREMENT, 
  bbs_title VARCHAR(100),
  bbs_content TEXT,
  bbs_writer VARCHAR(50),
  bbs_reg_date DATETIME DEFAULT CURRENT_TIMESTAMP 
-- , bbs_mod_date DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
  , bbs_count NUMERIC(10,0) DEFAULT 0
  , FOREIGN KEY (bbs_writer) REFERENCES member (mem_id)
);

select bbs_no, bbs_title, bbs_content, bbs_writer, bbs_reg_date, bbs_count from bbs b inner join attach a where bbs_no=
-- member 테이블에 레코드 1개 추가
-- mem_id는 'a001', mem_pass는 '1234', 
-- mem_name은 '고길동', mem_point는 100로 저장
INSERT INTO member 
( mem_id, mem_pass, mem_name, mem_point )
VALUES ( 'a001', '1234', '고길동', 100 );

INSERT INTO bbs ( bbs_title, bbs_content, bbs_writer  ) VALUES ( '제목60', '내용111', 'a001' );
commit;

SELECT * FROM bbs;

SELECT bbs_no, bbs_title, bbs_content, bbs_writer, bbs_reg_date FROM bbs WHERE bbs_title like CONCAT('%', '1', '%')limit , 10; 

-- 첨부파일 테이블 생성  
CREATE TABLE attach
( att_no INT PRIMARY KEY AUTO_INCREMENT, 
  att_org_name VARCHAR(255),
  att_new_name VARCHAR(255),
  att_bbs_no INT REFERENCES bbs (bbs_no)
--  ,PRIMARY KEY (att_no) 
--  ,FOREIGN KEY (att_bbs_no) REFERENCES attach (att_no)
);
select * from attach;

-- 해당 글과 그 글의 첨부파일 정보가 함께 조회되도록 
SELECT bbs_no, bbs_title, bbs_content, bbs_writer, bbs_reg_date, bbs_count, att_no, att_org_name, att_new_name, att_bbs_no
FROM bbs left outer join attach
on bbs_no = att_bbs_no
where bbs_no=18;

-- 댓글 테이블 생성  
CREATE TABLE reply
( rep_no INT PRIMARY KEY AUTO_INCREMENT, 
  rep_content TEXT,
  rep_writer VARCHAR(50) REFERENCES member (mem_id),
  rep_date DATETIME DEFAULT CURRENT_TIMESTAMP,
  rep_bbs_no INT REFERENCES bbs (bbs_no)
--  ,PRIMARY KEY (bbs_no) 
--  ,FOREIGN KEY (rep_bbs_no) REFERENCES bbs (bbs_no)
--  ,FOREIGN KEY (rep_writer) REFERENCES member (mem_id)
);


-- 상품 테이블 : 상품번호, 상품명, 상품가격, 상품설명, 제조사, (제조일자, 유통기한, 상품이미지) 
CREATE TABLE product
( prod_no INT PRIMARY KEY AUTO_INCREMENT,  
  prod_name VARCHAR(100),
  prod_price INT
);

insert into member (mem_id, mem_pass, mem_name, mem_point) values ('egleaves0', 'mnLdT7v', 'Emmet Gleaves', 62);
insert into member (mem_id, mem_pass, mem_name, mem_point) values ('iselland1', '1dOhPyWRH6V', 'Innis Selland', 50);
insert into member (mem_id, mem_pass, mem_name, mem_point) values ('ameharry2', 'YVIDPWloe9s', 'Aldin Meharry', 66);
insert into member (mem_id, mem_pass, mem_name, mem_point) values ('amangeot3', 'bvGUmn60', 'Andrea Mangeot', 11);
insert into member (mem_id, mem_pass, mem_name, mem_point) values ('bblunn4', 'HazuaEKdvWO6', 'Brittne Blunn', 59);
insert into member (mem_id, mem_pass, mem_name, mem_point) values ('memney5', 'd776z3', 'Marcela Emney', 16);
insert into member (mem_id, mem_pass, mem_name, mem_point) values ('lholywell6', 'laAcvhhZqY16', 'Laurella Holywell', 7);
insert into member (mem_id, mem_pass, mem_name, mem_point) values ('sbachelar7', 'smQp6K6H', 'Sunny Bachelar', 57);
insert into member (mem_id, mem_pass, mem_name, mem_point) values ('ogodmer8', 'jhcl9lbz', 'Odella Godmer', 6);
insert into member (mem_id, mem_pass, mem_name, mem_point) values ('strenholm9', 'FewyEbf5EF', 'Sigismundo Trenholm', 80);
insert into member (mem_id, mem_pass, mem_name, mem_point) values ('lclymaa', 'iGbrFhtH7', 'Lothaire Clyma', 46);
insert into member (mem_id, mem_pass, mem_name, mem_point) values ('mkohrsb', 'aUU1LPkq0z', 'Mahalia Kohrs', 10);
insert into member (mem_id, mem_pass, mem_name, mem_point) values ('cbelvinc', '3RJviCQo', 'Cynthy Belvin', 56);
insert into member (mem_id, mem_pass, mem_name, mem_point) values ('einnotd', 'Lgop7X9', 'Edouard Innot', 29);
insert into member (mem_id, mem_pass, mem_name, mem_point) values ('jfarnfielde', 'vf3QzN', 'Jemmy Farnfield', 95);
insert into member (mem_id, mem_pass, mem_name, mem_point) values ('hleaknerf', '8DYhuhsqH', 'Hamil Leakner', 63);
insert into member (mem_id, mem_pass, mem_name, mem_point) values ('jrobertog', '1ye8jMp', 'Jock Roberto', 18);
insert into member (mem_id, mem_pass, mem_name, mem_point) values ('twrinchh', 'vRsQizl', 'Terrel Wrinch', 30);
insert into member (mem_id, mem_pass, mem_name, mem_point) values ('omccrostiei', 'AgGqs5PN7wu', 'Osborne McCrostie', 25);
insert into member (mem_id, mem_pass, mem_name, mem_point) values ('dhankeyj', 'p8wgbIrZkv', 'Derk Hankey', 93);
insert into member (mem_id, mem_pass, mem_name, mem_point) values ('dfrancombk', 'EG4kPgaF', 'Donielle Francomb', 12);
insert into member (mem_id, mem_pass, mem_name, mem_point) values ('hcurwoodl', 'Eiytjz5rr9', 'Hedwiga Curwood', 79);
insert into member (mem_id, mem_pass, mem_name, mem_point) values ('ielbournem', '4jbFJC', 'Isabeau Elbourne', 59);
insert into member (mem_id, mem_pass, mem_name, mem_point) values ('jhewelln', 'r98HF6hnzH', 'Jaime Hewell', 10);
insert into member (mem_id, mem_pass, mem_name, mem_point) values ('lpenkmano', 'cdwElGbBw', 'Leoline Penkman', 93);
insert into member (mem_id, mem_pass, mem_name, mem_point) values ('ktweddellp', 'AgWHFLVSxEY', 'Kort Tweddell', 12);
insert into member (mem_id, mem_pass, mem_name, mem_point) values ('cpraundlq', 'HSlvwI', 'Cesar Praundl', 83);
insert into member (mem_id, mem_pass, mem_name, mem_point) values ('aandrysiakr', 'mKaKof4NjWx2', 'Adrienne Andrysiak', 34);
insert into member (mem_id, mem_pass, mem_name, mem_point) values ('etompsetts', 'z4P2qZLY', 'Elinore Tompsett', 89);
insert into member (mem_id, mem_pass, mem_name, mem_point) values ('gchavest', 'NvUAB0sPg', 'Gusta Chaves', 58);
insert into member (mem_id, mem_pass, mem_name, mem_point) values ('bmatzu', 'eA9lfn9zb6', 'Baudoin Matz', 3);
insert into member (mem_id, mem_pass, mem_name, mem_point) values ('lperroniv', 'f2uFaSx', 'Loretta Perroni', 54);
insert into member (mem_id, mem_pass, mem_name, mem_point) values ('dneamesw', 'PwFLh9GRYWn', 'Doug Neames', 31);
insert into member (mem_id, mem_pass, mem_name, mem_point) values ('jmorenax', 'BWDSa1', 'Joli Morena', 85);
insert into member (mem_id, mem_pass, mem_name, mem_point) values ('ehowlingy', 'BH5R48snmx', 'Elsworth Howling', 91);
insert into member (mem_id, mem_pass, mem_name, mem_point) values ('lswiggsz', 'HzEB3qef4mdI', 'Laryssa Swiggs', 78);
insert into member (mem_id, mem_pass, mem_name, mem_point) values ('ldammarell10', 'wbQA6z', 'Loralee Dammarell', 26);
insert into member (mem_id, mem_pass, mem_name, mem_point) values ('cmelluish11', 'txf1DV', 'Celle Melluish', 3);
insert into member (mem_id, mem_pass, mem_name, mem_point) values ('tbarette12', 'CtUwlz', 'Tyrone Barette', 96);
insert into member (mem_id, mem_pass, mem_name, mem_point) values ('pbordman13', 'ejOhFoiy', 'Patsy Bordman', 2);
insert into member (mem_id, mem_pass, mem_name, mem_point) values ('lthorouggood14', 'O6Vovt0', 'Lainey Thorouggood', 47);
insert into member (mem_id, mem_pass, mem_name, mem_point) values ('ksarton15', 'OrCpCrvcwb', 'Krystalle Sarton', 12);
insert into member (mem_id, mem_pass, mem_name, mem_point) values ('btiebe16', '0b7R78EJYK', 'Brendin Tiebe', 22);
insert into member (mem_id, mem_pass, mem_name, mem_point) values ('lcromer17', 'JNgVXpOM', 'Lindie Cromer', 56);
insert into member (mem_id, mem_pass, mem_name, mem_point) values ('bgummoe18', 'P8Xcq15shryy', 'Bradford Gummoe', 36);
insert into member (mem_id, mem_pass, mem_name, mem_point) values ('lroycroft19', 'n2B42n1', 'Lucian Roycroft', 19);
insert into member (mem_id, mem_pass, mem_name, mem_point) values ('cezzell1a', 'M9v1akvIKg', 'Consuela Ezzell', 49);
insert into member (mem_id, mem_pass, mem_name, mem_point) values ('dvinker1b', 'uFtXOY', 'Davey Vinker', 74);
insert into member (mem_id, mem_pass, mem_name, mem_point) values ('ahalls1c', 'FHY2rSj', 'Annemarie Halls', 62);
insert into member (mem_id, mem_pass, mem_name, mem_point) values ('bmurley1d', 'XB9DGPlDYN', 'Betti Murley', 45);


select * from reply;

