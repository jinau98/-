package kr.ac.hit.myapp.reply;

public interface ReplyService {
	public int insert(ReplyVo vo);
}
