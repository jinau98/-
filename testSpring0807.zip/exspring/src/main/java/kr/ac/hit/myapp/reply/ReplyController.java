package kr.ac.hit.myapp.reply;

import java.util.HashMap;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import kr.ac.hit.myapp.bbs.BbsVo;
import kr.ac.hit.myapp.member.MemberVo;

@Controller
public class ReplyController {
	@Resource
	private ReplyService replyService;

	@RequestMapping(value = "/reply/add.do")
//	@RequestMapping(value = "/reply/add.do", method = RequestMethod.POST)
//	public String add(ReplyVo vo, HttpSession session) {
//		MemberVo loginUser = (MemberVo) session.getAttribute("loginUser"); // 로그인한 사용자
//		vo.setRepWriter(loginUser.getMemId()); // 로그인한 사용자 아이디로 글쓴이를 강제설정
//
//		int num = replyService.insert(vo);
//		return "";
//	}
	@ResponseBody
	public Map<String, Object>add(ReplyVo vo, HttpSession session) {
		MemberVo loginUser = (MemberVo) session.getAttribute("loginUser"); // 로그인한 사용자
		vo.setRepWriter(loginUser.getMemId()); // 로그인한 사용자 아이디로 글쓴이를 강제설정
		int num = replyService.insert(vo);
		Map<String, Object> resultMap = new HashMap<String, Object>();
		resultMap.put("result", num);
		return resultMap;
	}
}
