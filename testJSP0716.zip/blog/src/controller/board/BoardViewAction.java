package controller.board;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import controller.Action;
import model.Board;
import repository.BoardRepository;

public class BoardViewAction implements Action{

	private static final String TAG = "BoardViewAction : ";
	
	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		System.out.println(TAG+"진입");
		String url = "board/view.jsp";
		
		int id=Integer.parseInt(request.getParameter("id"));
		System.out.println(TAG+"id : " +id);
		
		BoardRepository br = new BoardRepository();
		Board b = br.findById(id);
		
		request.setAttribute("board", b);
		
		RequestDispatcher dis = request.getRequestDispatcher(url);
		dis.forward(request, response);
	}
}
